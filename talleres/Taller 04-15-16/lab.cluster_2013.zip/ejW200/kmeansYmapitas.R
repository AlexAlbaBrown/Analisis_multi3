####
#### CLUSTER NO-jerarquico CON el conjunto de datos  W2000 #########
####


rm(list=ls())

dat = read.table('w2000.txt',sep='\t',header=TRUE,row.names=1)
dat$REGION = factor(dat$REGION)
levels(dat$REGION) = c('OECD','EuropaEste','Asia','Africa','OrienteMEdio','AmericaLatina') # le cambio los niveles al factor


DATOSst = scale(dat[,3:13]) # otra forma

?kmeans

k <- 5
agrupo <- kmeans(DATOSst, k)
names(agrupo)


cl <- agrupo$cluster


by(row.names(dat),cl,print)

plot(dat[,3:13],col=cl, pch=16)






# MAPAS!!??? que divertido!


dat <- read.table('w2000.txt',sep='\t',header=TRUE)
names(dat)[3] <- 'zona'
head(dat)


GRU <- cbind(dat,cl)

library(rworldmap)
?joinCountryData2Map

MAPA <- joinCountryData2Map(GRU,joinCode='NAME',nameJoinColumn='COUNTRY')

class(MAPA)
names(MAPA)

mapCountryData(MAPA,nameColumnToPlot='GDP_CAP')
mapCountryData(MAPA,nameColumnToPlot='zona',addLegend=TRUE)
mapCountryData(MAPA,nameColumnToPlot='cl',catMethod='categorical',numCats=3)
GRU$cl
GRU[,c(1,17)]
