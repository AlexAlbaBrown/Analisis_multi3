#### LAB cluster
# EJEMPLITO k-means 2-dimensional
require(graphics)
x <- rbind(matrix(rnorm(100, sd = 0.3), ncol = 2), matrix(rnorm(100, mean = 1, sd = 0.3), ncol = 2))
colnames(x) <- c("x", "y")

(cl <- kmeans(x, 2))
(cl3 <- kmeans(x, 3))
(cl5 <- kmeans(x, 5))
(cl7 <- kmeans(x, 7))

# grafico de los 4 agrupamientos
par(mfrow=c(2,2))
plot(x, col = cl$cluster,pch = 19,cex=0.5); points(cl$centers, col = 1:2, pch = 8, cex=2); title('2 grupos')
plot(x, col = cl3$cluster,pch = 19,cex=0.5); points(cl3$centers, col = 1:3, pch = 8, cex=2); title('3 grupos')
plot(x, col = cl5$cluster,pch = 19,cex=0.5); points(cl5$centers, col = 1:5, pch = 8, cex=2); title('5 grupos')
plot(x, col = cl7$cluster,pch = 19,cex=0.5); points(cl7$centers, col = 1:7, pch = 8, cex=2); title('7 grupos')



# grafico betweenss/totss para varios agrupamientos
GRILLA <- c(seq(10),seq(11,95,5))
r <- NULL
for (i in GRILLA)
{
    clX <- kmeans(x, i)
    r <- c(r,(clX$betweenss/clX$totss)*100)
    print(i)
}
r
plot(GRILLA,r,type='b')
abline(v=GRILLA,col='red')


